import os

def get_csv_paths(input_path):
    files_path = []  # stores all the files path
    doc_format = "gz"  # CSV file format

    for root, dirs, files in os.walk(input_path):
        for file in files:
            if file.endswith("." + doc_format):
                files_path.append(os.path.join(root, file))

    return files_path