# Contents of trace_utils.py

import gzip
import shutil
import os
import pandas as pd
import json
from shapely.geometry import Point
import datetime
def unzip_gz_and_read_csv(gz_file_path, output_directory):
    """
    Unzip a .gz file, save the CSV, and return the DataFrame and output CSV file path.

    Parameters:
    gz_file_path (str): Path to the .gz file.
    output_directory (str): Directory to save the extracted CSV file.

    Returns:
    pd.DataFrame, str: DataFrame containing the extracted CSV data, path to the saved CSV file.
    """
    # Ensure the output directory exists
    os.makedirs(output_directory, exist_ok=True)

    # Determine the output CSV file path by removing '.gz' extension
    csv_filename = os.path.basename(gz_file_path).replace('.gz', '')
    output_csv_file = os.path.join(output_directory, csv_filename)

    # Open the .gz file and write the contents to the output CSV file
    with gzip.open(gz_file_path, 'rb') as f_in:
        with open(output_csv_file, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

    # Read the extracted CSV file into a DataFrame
    df = pd.read_csv(output_csv_file)

    # Delete the CSV file after reading it
    # os.remove(output_csv_file)

    return df #, output_csv_file


def unzip_and_read_csv(zip_file_path, output_directory):
    """
    Unzip a .zip file and save as CSV, returning the DataFrame and output CSV file path.

    Parameters:
    zip_file_path (str): Path to the .zip file.
    output_directory (str): Directory to save the extracted CSV file.

    Returns:
    pd.DataFrame, str: DataFrame containing the extracted CSV data, path to the saved CSV file.
    """
    shutil.unpack_archive(zip_file_path, output_directory)
    # Extract the directory name
    directory_name = zip_file_path.split('\\')[-1]  # Split by '/' and take the last element
    output_directory = os.path.join(output_directory, directory_name)
    os.makedirs(output_directory, exist_ok=True)
    output_csv_file = None

    with gzip.open(zip_file_path, 'rb') as f_in:
        csv_filename = os.path.basename(zip_file_path).replace('.zip', '')
        output_csv_file = os.path.join(output_directory, csv_filename)
        
        with open(output_csv_file, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

    if output_csv_file:
        df = pd.read_csv(output_csv_file)
        return df, output_csv_file
    else:
        print("Failed to unzip and save the CSV file.")
        return None

def save_visitor_list(input_path,  visitors, file_count):
    """
    Save a list of visitors to a JSON file.

    Parameters:
    input_path (str): Input path of the original file.
    file_path (str): File path where the visitors are saved.
    visitors (set): Set of visitors to save.
    file_count (int): File count identifier.

    Returns:
    str: Path of the saved JSON file.
    """
    # output_dir = os.path.join(os.path.dirname(input_path), 'List of Visitors')
    
    # script_dir = os.path.dirname(os.path.abspath(__file__))
    # os.chdir(script_dir)

    # Create the output directory in the root directory
    #     timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    # output_directory = os.path.join(output_directory, f'{timestamp}')
    output_dir = os.path.join(input_path, 'List of Visitors')
    os.makedirs(output_dir, exist_ok=True)
    # input_file_name = os.path.basename(os.path.splitext(input_path)[0])
    output_json_path = os.path.join(output_dir, f'Distinct_visitors_upto-{file_count}.json')

    list_of_visitors = list(visitors)

    with open(output_json_path, 'w') as json_file:
        json.dump(list_of_visitors, json_file, indent=4)

    return output_json_path

def is_within_shape(row, shape, visitors, latitude_min_max_list, longitude_min_max_list):
    """
    Check if a visitor's location (latitude, longitude) is within a specified shape.

    Parameters:
    row (pd.Series): A row from the DataFrame containing visitor data.
    shape (geopandas.GeoSeries): Shape to check against.
    visitors (set): Set of existing visitors.

    Returns:
    bool: True if the visitor's location is within the shape, False otherwise.
    """
    if row['DEVICE_ID'] not in visitors:
        if longitude_min_max_list[0] < row['LONGITUDE'] < longitude_min_max_list[1]:
            if latitude_min_max_list[0] < row['LATITUDE'] < latitude_min_max_list[1]:
                point = Point(row['LONGITUDE'], row['LATITUDE'])
                return shape.contains(point).any()
            else:
                return False
        else:
            return False
    else:
        return False

def process_trace_data(input_path, output_directory, json_file_output_path, visitors, file_count, chunk_size, shape_file, latitude, longitude):
    """
    Process trace data to check if visitors are within a specified shape.

    Parameters:
    input_path (str): Path to the input trace data.
    output_directory (str): Directory to save unzipped files.
    json_file_output_path (str): Path to save the JSON file containing visitor lists.
    visitors (set): Set of existing visitors.
    file_count (int): Identifier for the current file.
    chunk_size (int): Size of chunks to process.
    shape_file (geopandas.GeoSeries): Shape to check if visitors are within.
    latitude_min_max_list
    longitude_min_max_list

    Returns:
    set: Updated set of visitors.
    """
    # timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    # output_directory = os.path.join(output_directory, f'{timestamp}')
    os.makedirs(output_directory, exist_ok=True)
    output_json_path = None

    # Unzip and read the CSV file
    # df, file_path = unzip_and_read_csv(input_path, output_directory)
    
    
    # df, file_path = unzip_gz_and_read_csv(input_path, output_directory)
    df= unzip_gz_and_read_csv(input_path, output_directory)   
    
    # df= pd.read_csv(input_path)
    # df.rename(columns={'maid':'DEVICE_ID', 'datetime':'EVENT_DATE', 'longitude':'LONGITUDE','latitude':'LATITUDE'})
    
    # Check if DataFrame is not empty
    if not df.empty:
        num_records = len(df)

        # Process data in chunks
        for index in range(0, num_records, chunk_size):
            end_index = min(num_records, index + chunk_size)
            selected_data = df.iloc[index:end_index].copy()

            # Apply is_within_shape function to filter visitors
            within_shape = selected_data.apply(lambda x: is_within_shape(x, shape_file, visitors, latitude, longitude), axis=1)
            selected_data['WITHIN_SHAPE'] = within_shape


            # Update visitors set with new visitors
            visitors.update(selected_data[selected_data['WITHIN_SHAPE']]['DEVICE_ID'].unique())

        # Save list of visitors to JSON file
        output_json_path = save_visitor_list(json_file_output_path, visitors, file_count)

    return visitors
