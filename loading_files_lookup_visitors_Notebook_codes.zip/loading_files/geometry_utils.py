import geopandas as gpd

def load_geometry(file_path):
    """
    Load a GeoJSON file and extract the geometry column.

    Parameters:
    file_path (str): The path to the GeoJSON file.

    Returns:
    geopandas.GeoSeries: The geometry column from the GeoJSON file.
    """
    poly_file = gpd.read_file(file_path)
    shape_uttarakhand = poly_file["geometry"]
    return shape_uttarakhand
