import os
import json

def get_files(path, save_path, doc_format="gz"):
    """
    Get a sorted list of files with a specific format from a directory and its subdirectories.

    Parameters:
    path (str): The directory path to search for files.
    doc_format (str): The file format to search for (default is "gz").

    Returns:
    dict: A dictionary with file indices as keys and file paths as values.
    """
    os.chdir(path)
    files_path = []

    for folder_name in os.listdir():
        folder_path = os.path.join(path, folder_name)
        if os.path.isdir(folder_path):
            try:
                all_files = os.listdir(folder_path)
                for file_data in all_files:
                    file_path = os.path.join(folder_path, file_data)
                    if file_path.split(".")[-1] == doc_format:
                        files_path.append(file_path)
            except Exception as e:
                print(f"Error accessing {folder_name}: {e}")
    
    files_path.sort()
    
    file_no = {i: files_path[i] for i in range(len(files_path))}
    # Ensure the save directory exists
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    # Save the file_no dictionary to a JSON file
    save_file = os.path.join(save_path, 'file_no.json')
    with open(save_file, 'w') as f:
        json.dump(file_no, f, indent=4)

    print(f"file_no saved to {save_file}")

    return files_path
