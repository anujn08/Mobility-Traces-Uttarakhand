import os
import json
import gzip
import shutil
import pandas as pd
import time
from shapely.geometry import Point
from tqdm import tqdm

def unzip_and_read_csv(gz_file_path, output_directory):
    os.makedirs(output_directory, exist_ok=True)
    output_csv_file = None

    with gzip.open(gz_file_path, 'rb') as f_in:
        csv_filename = os.path.basename(gz_file_path).replace('.gz', '')
        output_csv_file = os.path.join(output_directory, csv_filename)
        
        with open(output_csv_file, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

    if output_csv_file:
        df = pd.read_csv(output_csv_file)
        return df, output_csv_file
    else:
        print("Failed to unzip and save the CSV file.")
        return None, None

def save_visitor_list(input_path, file_path, visitors, file_count):
    output_dir = os.path.join(os.path.dirname(input_path), 'List of Visitors')
    os.makedirs(output_dir, exist_ok=True)

    input_file_name = os.path.basename(os.path.splitext(input_path)[0])
    output_json_path = os.path.join(output_dir, f'Distinct_visitors_upto_{file_count}.json')

    list_of_visitors = list(visitors)
    with open(output_json_path, 'w') as json_file:
        json.dump(list_of_visitors, json_file)
    return output_json_path
