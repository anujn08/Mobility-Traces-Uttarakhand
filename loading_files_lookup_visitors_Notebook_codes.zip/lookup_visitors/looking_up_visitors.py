import os
import pandas as pd
import time
from tqdm import tqdm
import json
import datetime



def get_last_json_file(folder_path):
    """
    Get the path of the last JSON file in the specified folder.

    Parameters:
    folder_path (str): Path to the folder containing the JSON files.

    Returns:
    str: Path to the last JSON file.
    """
    # List all files in the folder
    # files = os.listdir(folder_path)

    doc_format = "json" 
    json_files=[]
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith("." + doc_format):
                full_path = os.path.join(root, file)
                json_files.append(full_path)
    
    # Filter out only the JSON files
    # json_files = [f for f in files if f.endswith('.json')]
    
    if not json_files:
        raise ValueError("No JSON files found in the specified folder.")
    # print(f'JSON FILES[0]: {json_files[0]}')
    # Sort the files by their numerical suffix
    json_files.sort(key=lambda x: int(x.split('-')[-1].split('.')[0]))
    
    # Get the last file
    last_file = json_files[-1]
    
    print(f'last file: {last_file}')

    with open(last_file,'r') as f:
        visitors = json.load(f)
    # return os.path.join(folder_path, last_file)
    return set(visitors)


# Function to trace all visitors from a single file
def trace_all_visitors(input_path, visitors):
    start_time = time.time()  # Record start time

    # Load data into a Pandas DataFrame
    print(f'\nInput file: {input_path}')
    data = pd.read_csv(input_path)
    data.rename(columns= {'DEVICE_ID':'maid', 'EVENT_DATE': 'datetime', 'LATITUDE':'latitude', 'LONGITUDE':'longitude'}, inplace=True)
    data_shape = data.shape[0]
    print(f'\nShape of file: {data.shape}')

    # Filter out records of visitors who visited Uttarakhand
    # data = data[data['DEVICE_ID'].isin(visitors)]
    data = data[data['maid'].isin(visitors)]
    print(f'\nShape of file after filtering : {data.shape}')

    end_time = time.time()  # Record end time
    elapsed_time = end_time - start_time  # Calculate elapsed time
    print(f"\nTime taken for reading {input_path} data with {data_shape} records: {elapsed_time} seconds")
    print('\nPROCESSED THE FILE______')

    # Return relevant columns
    # data = data[['DEVICE_ID', 'LATITUDE', 'LONGITUDE', 'EVENT_DATE']]
    data = data[['maid', 'latitude', 'longitude', 'datetime', 'ACCURACY']]
    # data['EVENT_DATE'] = pd.to_datetime(data['EVENT_DATE'])
    data['datetime'] = pd.to_datetime(data['datetime'])
    # return data[['DEVICE_ID', 'LATITUDE', 'LONGITUDE', 'EVENT_DATE']]
    return data

# Main function to process all files and extract Uttarakhand visitors
def lookup_visitors(input_dir, visitors, file_save_path):
    # columns = ['DEVICE_ID', 'LATITUDE', 'LONGITUDE', 'EVENT_DATE']
    columns = ['maid', 'latitude', 'longitude', 'datetime', 'ACCURACY']
    
    part_dirs = [d for d in os.listdir(input_dir) if os.path.isdir(os.path.join(input_dir, d))]
    print(part_dirs)
    print(f'Inside lookup_visitors')
    print(f'Input path: {input_dir}')

        # If part_dirs is empty, set part_dirs to [input_dir] to process files in the input_dir itself
    if not part_dirs:
        part_dirs = [input_dir]
        print(f'No subdirectories found, processing files directly in {input_dir}')



    for part_dir in part_dirs:
        # print(f'\nProcessing directory: {part_dir}')
        part_path = os.path.join(input_dir, part_dir)
        # files_path = [os.path.join(part_path, f) for f in os.listdir(part_path) if f.endswith('.csv')]
        files_path=[]
        x_files=[]
        for root, dirs, files in os.walk(part_path):
            print(f'\nProcessing directory: {root}')
            file = [os.path.join(root, f) for f in files if f.endswith('.csv')]
            x= [f for f in files if f.endswith('.csv')]
            files_path.extend(file)
            x_files.extend(x)

        print(f'file: {x_files}')
        total_visitors = pd.DataFrame(columns=columns)
        count = len(files_path)
        print(f'Total number of files in {part_dir}: {count}')

        for itr in tqdm(range(count), desc=f"Processing files in {part_dir}"):
            temp_df = trace_all_visitors(files_path[itr], visitors)
            # total_visitors = pd.concat([total_visitors, temp_df])
            # timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            # file_save_path = file_save_path + f'\filtered_records_{timestamp}'
            output_file_path = os.path.join(file_save_path, f'filtered_records_{x_files[itr]}')
            os.makedirs(file_save_path, exist_ok=True)
            temp_df.to_csv(output_file_path, index=False)
            # print(f'\nTotal visitors shape: {total_visitors.shape}')

        
        # output_file_path = os.path.join(file_save_path, f'filtered_records_{timestamp}')
        # os.makedirs(file_save_path, exist_ok=True)
        # # output_file_path = os.path.join(file_save_path, f'total_visitors_{part_dir}.csv')
        # total_visitors.to_csv(output_file_path, index=False)
        # print(f'Data saved as: {output_file_path}')

# if __name__ == "__main__":
#     # Example usage
#     input_dir = r'C:\Users\Admin\Desktop\Desktop\Mobility_traces_code\output_dir_unzipped_csv'  # Replace with your actual input directory

#     # Assuming visitors is defined somewhere
#     with open(r'C:\Users\Admin\Desktop\Desktop\Mobility_traces_code\JSON_files\List of Visitors\Distinct_visitors_upto_3.json', 'r') as f:
#         visitors = json.load(f)
#     visitors = set(visitors)

    # lookup_visitors(input_dir, visitors)

# import os
# import pandas as pd
# import time
# from tqdm import tqdm
# import json

# # Function to trace all visitors from a single file
# def trace_all_visitors(input_path, visitors):
#     start_time = time.time()  # Record start time

#     # Load data into a Pandas DataFrame
#     print(f'\nInput file: {input_path}')
#     data = pd.read_csv(input_path)
#     data_shape = data.shape[0]
#     print(f'\nShape of file: {data.shape}')

#     # Filter out records of visitors who visited Uttarakhand
#     data = data[data['DEVICE_ID'].isin(visitors)]
#     print(f'\nShape of file after filtering on basis of Uttarakhand visit: {data.shape}')

#     end_time = time.time()  # Record end time
#     elapsed_time = end_time - start_time  # Calculate elapsed time
#     print(f"\nTime taken for reading {input_path} data with {data_shape} records: {elapsed_time} seconds")
#     print('\nPROCESSED THE FILE______')

#     # Return relevant columns
#     data = data[['DEVICE_ID', 'LATITUDE', 'LONGITUDE', 'EVENT_DATE']]
#     data['EVENT_DATE']= pd.to_datetime(data['EVENT_DATE'])
#     return data[['DEVICE_ID', 'LATITUDE', 'LONGITUDE', 'EVENT_DATE']]

# # Main function to process all files and extract Uttarakhand visitors
# def lookup_visitors(input_dir, files_path, visitors):
#     columns = ['DEVICE_ID', 'LATITUDE', 'LONGITUDE', 'EVENT_DATE']
#     total_visitors = pd.DataFrame(columns=columns)
#     flag = True
#     count = len(files_path)
#     print(f'Total number of files: {count}')

#     for itr in tqdm(range(count), desc="Processing files to trace all visitors data"):
#         temp_df = trace_all_visitors(files_path[itr], visitors)
#         total_visitors = pd.concat([total_visitors, temp_df])

#         # if (itr + 1) % 16 == 0:
#             # subset_number = (itr + 1) // 16
#         print(f'\nTotal visitors shape: {total_visitors.shape}')
#         # file_save_path = f'/content/drive/MyDrive/Sample_Traces_data/Filtered_records_for_New_Data_files'
#         # os.makedirs(file_save_path, exist_ok=True)
#         # total_visitors.to_csv(f'{file_save_path}/filtered_data_{itr}.csv', index=False)
#         # print(f'Data saved as: {file_save_path}/filtered_data_{subset_number}.csv')
#         # total_visitors = pd.DataFrame(columns=columns)

#     # if flag:
#         # subset_number = (itr + 1) // 16 + 1
#     file_save_path = r'C:\Users\Admin\Desktop\Desktop\Mobility_traces_code\filtered_records'
#     os.makedirs(file_save_path, exist_ok=True)
#     total_visitors.to_csv(f'{file_save_path}/filtered_data_.csv', index=False)
#     print(f'Data saved as: {file_save_path}/filtered_data_.csv')

# if __name__ == "__main__":
#     # Example usage
#     input_dir = r'C:\Users\Admin\Desktop\Desktop\Mobility_traces_code\output_dir_unzipped_csv'  # Replace with your actual input directory
#     files_path = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if f.endswith('.csv')]

#     # Assuming visitors is defined somewhere
#     # visitors = {'maid1': 'value1', 'maid2': 'value2'}  # Replace with your actual dictionary
#     # visitors=[]
#     with open(r'C:\Users\Admin\Desktop\Desktop\Mobility_traces_code\Mobility_traces_json_unzipped_files_bkp\List of Visitors\Distinct_visitors_upto_3.json', 'r') as f:
#         visitors =json.load(f)
#     visitors=set(visitors)

#     lookup_visitors(files_path, visitors)
